Will store the files uploaded to the application
